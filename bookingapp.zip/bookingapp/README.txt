PROJECT NAME

Python Appointment Booking app 

Description

Python appointment booking app is an app which provides functionality to book and schedule 
appointments. The app was/will be built using Django.

Roadmap

1. Setup python
2. Setup virtual environment
3. Setup Django
4. Configure URL's and views
5. Implement user login and gated content
6. Implement booking functionality